#include "ColourData.h"



ColourData::ColourData()
{
}


ColourData::~ColourData()
{
}
