#pragma once
#include "ColourData.h"
class Utils
{
public:
	Utils();
	~Utils();

	static ColourData Blue;
	static ColourData Red;
	static ColourData Green;
	static ColourData Grey;
};

