#include "Utils.h"



Utils::Utils()
{
}


Utils::~Utils()
{
}

ColourData Utils::Blue = { 0.062f, 0.168f, 0.819f };
ColourData Utils::Red = { 0.819f, 0.062f, 0.098f };
ColourData Utils::Green = { 0.086f, 0.6f, 0.058f };
ColourData Utils::Grey = { 0.529f, 0.529f, 0.529f };