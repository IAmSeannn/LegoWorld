#pragma once
struct ColourData
{
	float r;
	float g;
	float b;
};

